﻿using Buoi6.Areas.Admin.code;
using Buoi6.Areas.Admin.Models;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Buoi6.Areas.Admin.Controllers
{
    public class LoginController : Controller
    {
        string err = string.Empty;
        //
        // GET: /Admin/Login/
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(AccountModel model)
        {
            var result = new AccountDb().Login(ref err, model.UserName, model.PassWord);
            if (result && ModelState.IsValid)
            {
                SessionHelper.Setsession(new Session() { UserName = model.UserName });
                return RedirectToAction("Index", "Home", new { Areas = "Admin"});
            }
            else
            {
                ModelState.AddModelError("", "UserName or Password wrong");
            }
            return View(model);
        }

        public ActionResult Logout()
        {
            SessionHelper.Setsession(null);
            return RedirectToAction("Index", "Home", new { Areas = "Admin" });
        }
	}
}