﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Buoi6.Areas.Admin.code
{
    public class SessionHelper
    {
        public static void Setsession(Session session)
        {
            HttpContext.Current.Session["loginSession"] = session;

        }

        public static Session Getsession()
        {
            var session = HttpContext.Current.Session["loginSession"];
            if (session == null)
            {
                return null;
            }
            return session as Session;
        }
    }
}